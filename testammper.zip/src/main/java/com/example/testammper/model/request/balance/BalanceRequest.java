package com.example.testammper.model.request.balance;

import lombok.Data;

@Data
public class BalanceRequest {
    private int id;
    private String dateForm;
    private String dateTo;
}
