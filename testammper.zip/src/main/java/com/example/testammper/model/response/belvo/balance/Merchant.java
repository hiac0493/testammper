package com.example.testammper.model.response.belvo.balance;

import lombok.Data;

@Data
public class Merchant {
    private String logo;
    private String name;
    private String website;
}
