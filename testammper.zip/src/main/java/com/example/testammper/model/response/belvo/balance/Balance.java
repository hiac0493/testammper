package com.example.testammper.model.response.belvo.balance;

import lombok.Data;

@Data
public class Balance {
    private double current;
    private double available;
}
