package com.example.testammper.model.response.belvo.balance;

import lombok.Data;

@Data
public class Institution {
    private String name;
    private String type;
}
