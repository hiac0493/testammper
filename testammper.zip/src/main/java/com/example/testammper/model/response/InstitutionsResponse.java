package com.example.testammper.model.response;

import lombok.Data;

@Data
public class InstitutionsResponse {
    private int id;
    private String displayName;
    private String name;
}
